<?php 


include '../dbcon.php' 

?>







