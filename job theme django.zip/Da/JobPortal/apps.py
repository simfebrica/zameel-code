from django.apps import AppConfig


class JobportalConfig(AppConfig):
    name = 'JobPortal'
