<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="bootstrap-3.1.1/bootstrap.css" rel="stylesheet" type="text/css">
<script src="ckeditor/ckeditor.js"></script>
<script src="ckeditor/adapters/jquery.js"></script>
<script src="editor.js"></script>
            <title>Multiple Mail Sender Deluxe</title>


</head>

<body>
<table align="center">
<form action="mailform.php" method="post">
<tr><td colspan="2" align="center"><h1> MULTIPLE MAIL SENDER DELUXE </h1></td></tr>
<tr>
	<td width="86" align="right"><label>From: </label></td>
    <td width="1220" align="left"><input type="text" name="from" required="required"></td>
</tr>
<tr>
	<td align="right"><label>Name: </label></td>
    <td align="left"><input type="text" name="fromname" required="required"></td>
</tr>

<tr>
	<td align="right" colspan=""><label>Send To: </label> </td>
    <td align="left" colspan="2"><textarea class="textarea" cols="200" rows="10" name="to" required="required" style="width:86%"></textarea></td>
</tr>


<tr>
	<td align="right"><label>Subject/Title: </label> </td>
    <td align="left"><input type="text" name="subject" required="required" style="width:78%"></td>
</tr>

<tr style="width:80px">
	<td align="right"><label>Message Body: </label> </td>
    <td align="left"><textarea name="message" required="required"  class="ckeditor"></textarea></td>
</tr>
<tr>
	<td align="right" style="margin:2px"><label>Reply To: </label> </td>
    <td align="left"><input type="text" name="replyto" style="width:78%"></td>
</tr>

<tr align="center">
	<td colspan="2"><input id="send" name="send" type="submit" value="Send Bulk Mail Now!!!"> || <input type="reset" value="Clear Field"></td>
</tr>
</form>
</table>
</body>
</html>
