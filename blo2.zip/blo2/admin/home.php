<div class="container-fluid">
	<div class="col-md-12 alert alert-info">
		Dashboard
	</div>
</div>