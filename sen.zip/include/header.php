










<!DOCTYPE html>
<html lang="en">



















<head>
  <meta charset="utf-8">
  <title>MIT</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/f.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: MIT
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body>

  <!--==========================
  Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a>
        <!-- Uncomment below if you prefer to use a text logo -->
        <!--<h1><a href="#hero">MIT</a></h1>-->
      </div>










  
      <nav id="nav-menu-container">
        <ul class="nav-menu">












 <li class="menu-has-children"><a href="blog/ind.php">category</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="iplo/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup</a></li>
                  <li><a href="server/index.php">admin</a></li>
                  <li><a href="products.php">products</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="contact.php">contactn 3</a></li>
              <li><a href="return/index.php">retn 4</a></li>
              <li><a href="paa/index.php">co.pay 5</a></li>
            
<li><a href="r/index.php">r</a></li>
            
</ul>
          </li>












          <li class="menu-active"><a href="#call-to-action">Entro ahora</a></li>
          <li><a href="#about">Cart</a></li>




          <li><a href="#services">Services</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
           












          

 <li><a href="blog/index.php">Blog</a></li>
 
         
        





















  <li class="menu-has-children"><a href="blog/ind.php">vendor products</a>
            <ul>
              <li><a href="vendor.php">vendor all prod</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="iplo/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup</a></li>
                  <li><a href="server/index.php">admin</a></li>
                  <li><a href="../index.php">hom </a></li>
                  <li><a href="index.php">home</a></li>
                </ul>
              </li>
              <li><a href="ecommerc/index.php">pc maker option</a></li>
                   

   <li><a href="#">Drop Down 5</a></li>
            </ul>
          </li>
        





       


<?php include ('r/customers/config.php');?>

<script src="r/customers/js/datatables.min.js"></script>


<?php include ("r/admin/q.php");?>



        </ul>










      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

	



    <!--==========================
    Call To Action Section
    ============================-->
    <section id="call-to-action">
      <div class="container wow fadeIn">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title"></h3>
            <p class="cta-text"> Duis aute
qqqqqqqqqqqqqqqqqqqqqqqqq
wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
wwwwwwwwwwwwwwwwwwwwwwwwwwwww
wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
wwwwwwwwwwwwwwwwwwwwww
qqqqqqqqqqqqqq







qqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqq
icia deserunt mollit anim id est laborum.</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#">Call To Action</a>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->


















</div>
</form>

</section>





    </div>









  </section><!-- #hero -->





































    </section><!-- #about -->








<script src="i2/js/jquery-3.2.1.min.js"></script>
<script src="i2/js/bootstrap.js"></script>

</body>


































  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>




















	
	 <section id="intro">



	
	
	






<?php include ('r/customers/config.php');?>

<script src="r/customers/js/datatables.min.js"></script>



				</div>





				</div>
    </div>





<?php include ('ecommerce/include/home/header.php');?>






</html>























	

