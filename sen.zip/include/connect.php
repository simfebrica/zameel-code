<?php
	$con=mysql_connect("localhost","root","s") or die ("DOWN!");
		if ($con) {
			mysql_select_db("s",$con);
           
		}
		else
		{
			die("DOWN");
		}	
?>
