



  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">






  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/magnific-popup/magnific-popup.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">






  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

















  <!-- =======================================================
    Theme Name: Reveal
    Theme URL: https://bootstrapmade.com/reveal-bootstrap-corporate-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body id="body">

  <!--==========================
    Top Bar
  ============================-->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container clearfix">
  
















      <div class="contact-info float-left">
        <i class="fa fa-envelope-o"></i> <a href="mailto:contact@example.com">contact@example.com</a>
        <i class="fa fa-phone"></i> +1 5589 55488 55
      </div>
      <div class="social-links float-right">
        <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
        <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
        <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
      </div>
    </div>
  </section>






  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">











      <div id="logo" class="pull-left">
        <h1><a href="#body"<class="scrollto"><span>SIMFEBRICA</span></a></h1>
       
<form method="post">  
<div>
<Center>
<input type="text" name="search" placeholder="SEARCH AVAILABLE HERE.."> 




<input type="image" title="Search" src="img/s.png" name="submit" alt="." />


</Center>






</div>
</form>

















 <!-- Uncomment below if you prefer to use an image logo -->








</div>


      



























      <nav id="nav-menu-container">
        <ul class="nav-menu">














          <li class="menu-active"><a href="index.php">Home</a></li>



          <li class="menu-active"><a href="user_index.php">Main</a></li>








          <li class="menu-active"><a href="logout.php">Signout</a></li>











          <li><a href="blog/index.php">vlog</a></li>


<?php include('include/connect.php');?>

<?php include('include/session.php');?> 






















        </ul>








      </nav><!-- #nav-menu-container -->
    </div>
  </header>










  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="lib/sticky/sticky.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>


</body>





