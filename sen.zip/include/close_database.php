<?php
	include($_SERVER['DOCUMENT_ROOT'].'/Simple News Publishing System/variables/variables.php'); 
	$connect->close();
?>