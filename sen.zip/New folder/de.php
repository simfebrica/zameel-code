<?php
	require_once 'coa.php';
	
	if(ISSET($_REQUEST['vid_id']) && ISSET($_REQUEST['vid_name'])){
		if(unlink($_REQUEST['vid_name'])){
			mysqli_query($conn, "DELETE FROM `vid` WHERE `vid_id` = '$_REQUEST[vid_id]'");
			header('location: index.php');
		}	
	}
?>