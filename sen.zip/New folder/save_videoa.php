<?php
	date_default_timezone_set('Asia/Manila');
	require_once 'coa.php';
	
	if(ISSET($_POST['save'])){
		$file_name = $_FILES['video']['name'];
		$file_temp = $_FILES['video']['tmp_name'];
		$file_size = $_FILES['video']['size'];
		
		if($file_size < 500000000){
			$file = explode('.', $file_name);
			$end = end($file);
			$allowed_ext = array('avi', 'flv', 'wmv', 'mov', 'mp4', 'mkv', 'mpeg');
			if(in_array($end, $allowed_ext)){
				$name = date("Ymd").time();
				$locatio = 'vida/'.$name.".".$end;
				if(move_uploaded_file($file_temp, $locatio)){
					mysqli_query($conn, "INSERT INTO `vid` VALUES('', '$name', '$locatio')") or die(mysqli_error());
					echo "<script>alert('Video Uploaded')</script>";
					echo "<script>window.locatio = 'vindex.php'</script>";
				}
			}else{
				echo "<script>alert('Wrong video format')</script>";
				echo "<script>window.locatio = 'in.php'</script>";
			}
		}else{
			echo "<script>alert('File too large to upload')</script>";
			echo "<script>window.locatio = 'vindex.php'</script>";
		}
	}
?>