

<?php include 'inc/a/header.php';?>








<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>


<?php 
$pd = new Product();
$fm = new Format();
 ?>
 <?php 
if (isset($_GET['delpro'])) {
    $id = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delpro']);
    $delPro = $pd->delProById($id);
}
 ?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Post List</h2>
        <?php 
                if (isset($delPro)) {
                    echo $delPro;
                }
                 ?>
        <div class="block">  
            <table class="data display datatable" id="example">
			<thead>
				<tr>
				
                                        	<th>l</th>
				
                                	<th>Name</th>
				
						
			
					<th>Br</th>
					<th>D</th>
					<th>Prc</th>
					<th>I</th>
					<th>T</th>
					<th>Act</th>
				</tr>
			</thead>
			<tbody>
				<?php 
                $getPd = $pd->getAllProduct();
                if ($getPd) {
                    $i=0;
                    while ($result = $getPd->fetch_assoc()) {
                        $i++; ?>
				<tr class="odd gradeX">
					<td><?php echo $i; ?></td>
					<td><?php echo $result['productName']; ?></td>
					<td><?php echo $result['catName']; ?></td>
					<td><?php echo $result['brandName']; ?></td>
					<td><?php echo $fm->textShorten($result['body'], 11); ?></td>
					<td><?php echo $result['price']; ?></td>
					<td><img src="admin/<?php echo $result['image']; ?>" height="40px" width="60px"></td>					
					<td>





		





	<?php 
              $getNpd = $pd->getNewProduct();


                      ?>

				


					     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">Deta</a></span></div>
				</div>
				
				<?php
                  
              



       ?> 









					
						</tr>




				<?php
                    }
                } ?>



		
			</div>
    </div>
 </div>









	</td>












			</tbody>
		</table>

       </div>
    </div>
</div>







