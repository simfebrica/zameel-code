<?php
	date_default_timezone_set('Asia/Manila');
	require_once 'conn.php';
	
	if(ISSET($_POST['save'])){
		$file_name = $_FILES['imag']['name'];
		$file_temp = $_FILES['imag']['tmp_name'];
		$file_size = $_FILES['imag']['size'];
		
		$query = mysqli_query($conn, "SELECT * FROM `imag`") or die(mysqli_error());
		$count = mysqli_num_rows($query);
		
		if($count < 5){
			if($file_size < 2000000){
				$file = explode('.', $file_name);
				$end = end($file);
				$ext = array('jpg', 'png', 'jpeg');
				if(in_array($end, $ext)){
					$name = time().date("Ymd");
					$location = 'upload/'.$name.".".$end;
					if(move_uploaded_file($file_temp, $location)){
						mysqli_query($conn, "INSERT INTO `imag` VALUES('', '$name', '$location')") or die(mysqli_error());
						echo "<script>alert('File uploaded')</script>";
						echo "<script>window.location = 'i.php'</script>";
					}
				}else{
					echo "<script>alert('Wrong imag format')</script>";
					echo "<script>window.location = 'index.php'</script>";
				}
				
			}else{
				echo "<script>alert('File too large to upload')</script>";
				echo "<script>window.location = 'index.php'</script>";
			}
		}else{
			echo "<script>alert('Only 5 images can upload')</script>";
			echo "<script>window.location = 'index.php'</script>";
		}
	}
?>