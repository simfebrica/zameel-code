










<?php 
include 'li/Session.php';
Session::init();
include 'li/Database.php';
include 'helpers/Format.php';
// include 'classes/Product2.php';
// include 'classes/Cart.php';

spl_autoload_register(function ($class) {
    include_once "classes/".$class.".php";
});
$db = new Database();
$fm = new Format();
$pd = new Product();
$ct = new Cart();
$cat = new Category();
$cmr = new Customer();

 ?>
<?php
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache");
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
  header("Cache-Control: max-age=2592000");
?>
<!DOCTYPE HTML>
<head>
<title>S</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquerymain.js"></script>
<script src="js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
</head>
<body>
  <div class="wrap">
    <div class="header_top">
      <div class="logo">

    
      </div>
        <div class="header_top_right">
          <div class="search_box">
            <form>
              <input type="text" value="Search for Products" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
            </form>
          </div>
          <div class="shopping_cart">
          <div class="cart">
            <a href="#" title="View my shopping cart" rel="nofollow">
                <span class="cart_title">Cart</span>
                <span class="no_product">
                <?php 
                                $getData = $ct->checkCartItem();
                                if ($getData) {
                                    $sum = Session::get("gTotal");
                                    $qty = Session::get("qty");
                                    echo "$".number_format($sum).".00"." | Qty: ".$qty;
                                } else {
                                    echo '(Empty)';
                                }
                                
                                 ?>
                </span>
              </a>
            </div>
            </div>
            <?php 
                  if (isset($_GET['cid'])) {
                      $cmrId = Session::get("cmrId");
                      $delData = $ct->delCustomerCart();
                      $delComp = $pd->delCompareDara($cmrId);
                      Session::destroy();
                  }
                   ?>
        

       </div>
     <div class="clear"></div>
   </div>
   <div class="clear"></div>
 </div>
<div class="menu">
  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
    <li><a href="index.php">Home</a></li>   
    <li><a href="topbrands.php">Top Brands</a></li>
    <?php 
      $chkCart = $ct->checkCartItem();
      if ($chkCart) {
          ?>
        <li><a href="cart.php">Cart</a></li>
        <li><a href="payment.php">Payment</a></li>
      <?php
      }
       ?>
       <?php
      $cmrId = Session::get("cmrId");
      $chkOrder = $ct->checkOrder($cmrId);
      if ($chkOrder) {
          ?>        
        <li><a href="orderdetails.php">Order</a></li>
      <?php
      }
       ?>
    
<?php 
$login = Session::get("cuslogin");
if ($login == true) {
    ?>
  <li><a href="profile.php">Profile</a></li>
<?php
}
 ?>
    <?php $cmrId = Session::get("cmrId");
                            $getPd = $pd->getCompareData($cmrId);
                            if ($getPd) {
                                ?>
    <li><a href="compare.php">Compare</a> </li>
    <?php
                            } ?>
    <?php 
                            $checkWlist = $pd->getWlistData($cmrId);
                            if ($checkWlist) {
                                ?>
    <li><a href="wlist.php">Wish List</a></li>
    <?php
                            } ?>
    <li><a href="contact.php">Contact</a> </li>
    <div class="clear"></div>




 <div class="login">
        <?php 
$login = Session::get("cuslogin");
if ($login == false) {
    ?>
    <a href="login.php">Login</a>
<?php
} else {
        ?>
<a href="?cid=<?php Session::get('cmrId'); ?>">Logout</a>
<?php
    }
 ?>
        

       </div>
    





  </ul>
</div>














	



























<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>MIT</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/f.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: MIT
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body>

  <!--==========================
  Header
  ============================-->




<script src="i2/js/jquery-3.2.1.min.js"></script>
<script src="i2/js/bootstrap.js"></script>

</body>


































  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>




















	
	 <section id="intro">



	
	
	









				</div>





				</div>
    </div>





































<?php include 'inc/header.php'; ?>
<?php 
$login = Session::get("cuslogin");
if ($login == false) {
    header("Location:login.php");
}
 ?>
 <?php 
if (isset($_GET['orderid']) && $_GET['orderid'] == 'order') {
    $cmrId = Session::get("cmrId");
    $insertOrder = $ct->orderProduct($cmrId);
    
    $delData = $ct->delCustomerCart();
    header("Location:success.php");
}
  ?>
<style type="text/css">
.division{width:50%; float:left;}
.tblone{width: 95%; margin-right:15px; border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
.tbltwo{float:right; text-align:left; width:40%; border:2px solid #ddd; margin-right:14px; margin-top: -4px; margin-right: 38px;}
.tbltwo tr td{text-align:justify; padding: 5px 10px;}
.ordernow{}
.ordernow a{width:200px; margin:20px auto 0; text-align: center; padding:5px; font-size:30px; display: block; background: #3C3B40; color: white; border-radius: 3px;}
</style>
 
<div class="main">
	<div class="content">
		<div class="section group">
			<div class="division">
				<table class="tblone">
							<tr>
								<th>No</th>
								<th>Product</th>								
								<th>Price</th>
								<th>Quantity</th>
								<th>Total</th>								
							</tr>
							<?php 
                            $getPro = $ct->getCartProduct();
                            if ($getPro) {
                                $i=0;
                                $sum = 0;
                                $qty = 0;
                                while ($result = $getPro->fetch_assoc()) {
                                    $i++; ?>
							<tr>
								<td><?php echo $i; ?></td>
								<td><?php echo $result['productName']; ?></td>								
								<td>$<?php echo $result['price'].".00"; ?></td>
								<td><?php echo $result['quantity'].".00"; ?></td>								
								<td>$<?php
                                $total =  $result['price'] * $result['quantity'];
                                    echo number_format($total).".00"; ?></td>								
							</tr>
							<?php
                            $qty = $qty + $result['quantity'];
                                    $sum = $sum + $total; ?>
							<?php
                                }
                            } ?>
						</table>
						
						<table class="tbltwo">
							<tr>								
								<td>Sub Total</td>
								<td>:</td>
								<td>$<?php echo number_format($sum).".00"; ?></td>								
							</tr>
							<tr>
								<td>VAT 10%</td>
								<td>:</td>
								<td><?php 
                                $vat = $sum * 0.1;
                            echo "$".number_format($vat).".00"; ?></td>
							</tr>
							<tr>
								<td>Grand Total</td>
								<td>:</td>
								<td>$<?php 
                                $gTotal = $sum+$vat;
                            Session::set("gTotal", $gTotal);
                            echo number_format($gTotal).".00"; ?></td>
							</tr>
							<tr>								
								<td>Quantity</td>
								<td>:</td>
								<td><?php echo $qty; ?></td>								
							</tr>
					   </table>
			</div>			
			<div class="division">
				<?php 
            $id = Session::get("cmrId");
            $getData = $cmr->getCustomerData($id);
            if ($getData) {
                while ($result = $getData->fetch_assoc()) {
                    ?>
			<table class="tblone">
				<tr>
					<td colspan="3" style="text-align: center;"><h2>Your Profile Details</h2></td>					
				</tr>
				<tr>
					<td width="20%">Name</td>
					<td width="5%">:</td>
					<td><?php echo $result['name']; ?></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td>:</td>
					<td><?php echo $result['phone']; ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?php echo $result['email']; ?></td>
				</tr>
				<tr>
					<td>Address</td>
					<td>:</td>
					<td><?php echo $result['address']; ?></td>
				</tr>
				<tr>
					<td>City</td>
					<td>:</td>
					<td><?php echo $result['city']; ?></td>
				</tr>
				<tr>
					<td>Zip Code</td>
					<td>:</td>
					<td><?php echo $result['zip']; ?></td>
				</tr>
				<tr>
					<td>Country</td>
					<td>:</td>
					<td><?php echo $result['country']; ?></td>
				</tr>
				<tr>
					
					<td colspan="3" style="text-align: center; font-size: 22px;"><a style="color: green;" href="editprofile.php">Update Details</a></td>
					
				</tr>				
			</table>
			<?php
                }
            } ?>	
			</div>			
		</div>
		<div class="ordernow">
			<a href="?orderid=order">Order</a>
		</div>
	</div>
<?php include 'inc/footer.php'; ?>
