<?php
$con = mysqli_connect("localhost","root","","s") or die(mysql_error());

?>