<div class="span12">
	<a href="index.php"><img src="a_files/x_store.pn" alt=""/></a><embed src="img/cart.gif" class="pull-right"></embed></div> </div>



<div class="clr"></div>
</header>