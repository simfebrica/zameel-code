<?php
	$conn = mysqli_connect('localhost', 'root', '', 's');
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>