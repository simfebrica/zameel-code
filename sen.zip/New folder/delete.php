<?php
	require_once 'conn.php';
	
	if(ISSET($_REQUEST['imag_id']) && ISSET($_REQUEST['imag_name'])){
		if(unlink($_REQUEST['imag_name'])){
			mysqli_query($conn, "DELETE FROM `imag` WHERE `imag_id` = '$_REQUEST[imag_id]'");
			header('location: i.php');
		}	
	}
?>