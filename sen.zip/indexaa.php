










<!DOCTYPE html>
<html lang="en">








<section>



  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/f.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">









</section>



<section>

	<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" type="text/css" href="i2/css/bootstrap.css"/>
	</head>
<body>
	<div class="col-md-22"></div>
	<div class="col-md-55 well">
		<hr style="border-top:1px dotted #ccc;" />
		<br /><br />
		



<div id="myCarousel" class="carousel slide container-fluid" data-ride="carousel">
		<ol class="carousel-indicators">































			





















	
</div>


<br />










              




















		
	</div>
































<script src="i2/js/jquery-3.2.1.min.js"></script>
<script src="i2/js/bootstrap.js"></script>

</body>

















</section>

<section>

	<head>




		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" type="text/css" href="i2/css/bootstrap.css"/>
	</head>


	
		



</section>

<section>







	<head>	



<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.js"></script>
</body>

</section>

<style>
	.gallery__img {
	    width: 100%;
	    height: 100%;
	    object-fit: cover;
	}
	.gallery {
	    display: grid;
	    grid-template-columns: repeat(2, 50%);
	    grid-template-rows: repeat(2, 30vh);
	    grid-gap: 3px;
	    grid-row-gap: 3px;
	}
	.gallery__item{
		margin: 0
	}
</style>




</div>
</div>
<script>
	$('.comment-textfield').on('keypress', function (e) {
		if(e.which == 13 && e.shiftKey == false){
			if($('#preload2').length <= 0){
				start_load();
			}else{
				return false;
			}
			var post_id = $(this).attr('data-id')
			var comment = $(this).val()
			$(this).val('')
			$.ajax({
				url:'ajax.php?action=save_comment',
				method:'POST',
				data:{post_id:post_id,comment:comment},
				success:function(resp){
					if(resp){
						resp = JSON.parse(resp)
						if(resp.status == 1){
							var cfield = $('#comment-clone .card-comment').clone()
							cfield.find('.img-circle').attr('src','assets/uploads/'+resp.data.profile_pic)
							cfield.find('.uname').text(resp.data.name)
							cfield.find('.comment').html(resp.data.comment)
							cfield.find('.timestamp').text(resp.data.timestamp)
						$('.post-card[data-id="'+post_id+'"]').find('.card-comments').append(cfield)
						var cc = $('.post-card[data-id="'+post_id+'"]').find('.comment-count').text();
							cc = cc.replace(/,/g,'');
							cc = parseInt(cc) + 1
						$('.post-card[data-id="'+post_id+'"]').find('.comment-count').text(cc)
						}else{
							alert_toast("An error occured","danger")
						}
						end_load()
					}
				}
			})
			return false;
		}
    })
	$('.comment-textfield').on('change keyup keydown paste cut', function (e) {
		if(this.scrollHeight <= 117)
        $(this).height(0).height(this.scrollHeight);
    })
	$('#write_post').click(function(){
		uni_modal("<center><b>Create Post</b></center></center>","create_post.php")
	})
	$('.edit_post').click(function(){
		uni_modal("<center><b>Edit Post</b></center></center>","create_post.php?id="+$(this).attr('data-id'))
	})
	$('.delete_post').click(function(){
	_conf("Are you sure to delete this post?","delete_post",[$(this).attr('data-id')])
	})
	function delete_post($id){
			start_load()
			$.ajax({
				url:'ajax.php?action=delete_post',
				method:'POST',
				data:{id:$id},
				success:function(resp){
					if(resp==1){
						alert_toast("Data successfully deleted",'success')
						setTimeout(function(){
							location.reload()
						},1500)

					}
				}
			})
		}
	$('#upload_post').click(function(){
		uni_modal("<center><b>Create Post</b></center></center>","create_post.php?upload=1")
	})
	$('.content-field').each(function(){
		var dom = $(this)[0]
		var divHeight = dom.offsetHeight
		if(divHeight > 117){
			$(this).addClass('truncate-5')
			$(this).parent().children('.show-content').removeClass('d-none')
		}
	})
	$('.show-content').click(function(){
		var txt = $(this).text()
		if(txt == "Show More"){
			$(this).parent().children('.content-field').removeClass('truncate-5')
			$(this).text("Show Less")
		}else{
			$(this).parent().children('.content-field').addClass('truncate-5')
			$(this).text("Show More")
		}
	})
	$('.lightbox-items').click(function(e){
		e.preventDefault()
		uni_modal("","view_attach.php?id="+$(this).attr('data-id'),"large")
	})
	$('.view_more').click(function(e){
		e.preventDefault()
		uni_modal("","view_attach.php?id="+$(this).attr('data-id'),"large")
	})
	$('.like').click(function(){
		var _this = $(this)
		$.ajax({
			url:'ajax.php?action=like',
			method:'POST',
			data:{post_id:$(this).attr('data-id')},
			success:function(resp){
				if(resp == 1){
					_this.addClass('text-primary')
					var lc = _this.siblings('.counts').find('.like-count').text();
							lc = lc.replace(/,/g,'');
							lc = parseInt(lc) + 1
					_this.siblings('.counts').find('.like-count').text(lc)
				}else if(resp==0){
					_this.removeClass('text-primary')
					var lc = _this.siblings('.counts').find('.like-count').text();
							lc = lc.replace(/,/g,'');
							lc = parseInt(lc) - 1
					_this.siblings('.counts').find('.like-count').text(lc)
				}
			}
		})
	})

</script>



















<head>
  <meta charset="utf-8">
  <title>MIT</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/f.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">


  <link rel="stylesheet"  type= "text/css" href=" mosa.css">



  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: MIT
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body>




<section>







	<head>	
		</head>
<body>












	</div>
<script src="js/jquery-3.2.1.min.js"></script>

<script src="js/bootstrap.js"></script>
</body>

</section>





  <!--==========================
  Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">

        <a href="#hero"><img src="img/x_store.png" alt="" title="" /></img></a>

        <!-- Uncomment below if you prefer to use a text logo -->
        <!--<h1><a href="#hero">SIMFEBRICA</a></h1>-->
      </div>



  
      <nav id="nav-menu-container">
        <ul class="nav-menu">
























 <li class="menu-has-children"><a href="blog/ind.php">category</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  
                  <li><a href="u/index.php">upload 1</a></li>
               <li><a href="returnn/index.php">return 5</a></li>
                  
                  <li><a href="u/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup/signin</a></li>
                  <li><a href="admin/login.php">admin</a></li>
                  <li><a href="cart.php">cart</a></li>
                  <li><a href="topbrands.php">bbbbbb </a></li>
                </ul>
              </li>
              <li><a href="contact.php">contactn 3</a></li>
              <li><a href="return/index.php">return&vendorqqqmanage</a></li>
              <li><a href="payment.php">co.payment</a></li>
            
<li><a href="r/index.php">r</a></li>
            
</ul>
          </li>












          <li class="menu-active"><a href="#hero">Entro</a></li>
          <li><a href="#about">Cart</a></li>

<li><a href="#team">Team</a></li>



          <li><a href="#services">Services</a></li>
          <li><a href="restau/revie.php">review</a></li>
           












          

 <li><a href="blog/index.php">Blog</a></li>
 
         
        




  <li class="menu-has-children"><a href="login.php">vendor</a>
            <ul>
              <li><a href="">vendor all prod</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="iplo/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup</a></li>
                  <li><a href="server/index.php">admin</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="returnn/index.php">return 5</a></li>
                </ul>
              </li>
              <li><a href="ecommerc/index.php">pc maker option</a></li>
                   

   <li><a href="#">Drop Down 5</a></li>
            </ul>


















  <li class="menu-has-children"><a href="login.php">About</a>
            <ul>
              <li><a href="">vendor all prod</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="iplo/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup</a></li>
                  <li><a href="server/index.php">admin</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="ecommerc/index.php">pc maker option</a></li>
                   

   <li><a href="#">Drop Down 5</a></li>
            </ul>









 






  <li class="menu-has-children"><a href="login.php">LOGIN</a>
            <ul>
              <li><a href="vendor.php">vendor all prod</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="iplo/indexa.php">download 1</a></li>
                  <li><a href="register.php">signup</a></li>
                  <li><a href="server/index.php">admin</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="ecommerc/index.php">pc maker option</a></li>
                   

   <li><a href="#">Drop Down 5</a></li>
            </ul>










          </li>






















       




        



        </ul>





<section>
<script src="js/Table/jquery.datatables.min.js"></script>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.js"></script>


<?php 



include 'li/Database.php';


// include 'classes/Product2.php';
// include 'classes/Cart.php';

spl_autoload_register(function ($class) {
    include_once "classes/".$class.".php";
});

  ?>



<head>


    <!-- BEGIN: load jquery -->
    <script src="js/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery-ui/jquery.ui.core.min.js"></script>
    <script src="js/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.ui.mouse.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.ui.sortable.min.js" type="text/javascript"></script>
    <script src="js/table/jquery.dataTables.min.js" type="text/javascript"></script>
    <!-- END: load jquery -->



    <script type="text/javascript" src="js/table/table.js"></script>

    <script src="js/setup.js" type="text/javascript"></script>

     <script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            setSidebarHeight();
        });
    </script>













<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>


<?php 

			



$pd = new Product();
$fm = new Format();
 ?>
 <?php 
if (isset($_GET['delpro'])) {
    $id = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delpro']);
    $delPro = $pd->delProById($id);
}
 ?>

<div class="grid_10">
    <div class="box round first grid">

        <?php 
                if (isset($delPro)) {
                    echo $delPro;
                }
                 ?>
        <div class="block">  
            <table class="data display datatable" id="example">
			<thead>
				<tr>
				                	<th>l</th>
			
                             
                                	<th>Name</th>
				
						
			
					<th>Br</th>
					<th>D</th>
					<th>Prc</th>
					<th>I</th>
					<th>T</th>
					<th>Act</th>
				</tr>
			</thead>
			<tbody>
				<?php 
                $getPd = $pd->getAllProduct();
                if ($getPd) {
                    $i=0;
                    while ($result = $getPd->fetch_assoc()) {
                        $i++; ?>
				<tr class="odd gradeX">
					<td><?php echo $i; ?></td>
					<td><?php echo $result['productName']; ?></td>
					<td><?php echo $result['catName']; ?></td>
					<td><?php echo $result['brandName']; ?></td>
					<td><?php echo $fm->textShorten($result['body'], 11); ?></td>
					<td><?php echo $result['price']; ?></td>
					<td><img src="admin/<?php echo $result['image']; ?>" height="40px" width="60px"></td>					
					<td>





		





	<?php 
           $getNpd = $pd->getNewProduct();
              

                      ?>

				


					     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">cart</a></span></div>
				</div>
				
				<?php
                  
              



       ?> 









					
						</tr>




				<?php
                    }
                } ?>



		
			</div>
    </div>
 </div>









	</td>












			</tbody>
		</table>

       </div>
    </div>
</div>

</section?









      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

	






  <!--==========================
    Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">



			

      <h1> Wellcome To Simfebrica</h1>
      <h2>A Computer service Agency with <strong>Years Of Experience</strong></p>
				</h2>








      <a href="#about" class="btn-get-started">Get Started              
</a>
    </div>






<section>



  </section><!-- #hero -->































    </section>






























<section>









  <main id="main">

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">










qqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqq
qqqqqqqqq
















<section>


<div id="myCarousel" class="carousel slide container-fluid" data-ride="carousel">
		<ol class="carousel-indicators">
			<?php
				require 'conn.php';
				
				$query = mysqli_query($conn, "SELECT * FROM `imag` ORDER BY `imag_id` ASC") or die(mysqli_error());
				$count = mysqli_num_rows($query);
				if($count > 0){
					for($i=0; $i < $count; $i++){
			?>
						<li data-target="#myCarousel" data-slide-to="<?php echo $i?>" <?php if($i===0){echo "class='active'";}?>></li>
			<?php
					}
			?>
		</ol>
		<div style = "margin:auto;" class="carousel-inner" role="listbox">
			<?php
					$x = 0;
					while($fetch = mysqli_fetch_array($query)){
			?>
					<div class="item <?php if($x === 0){echo "active";}?>">
						<img src="<?php echo $fetch['location']?>" style = "width:100%; height:300px;" />
					</div>
			<?php
					$x++;
					}
			?>
			
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only"></span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only"></span>
		</a>	
</div>
<br />
<div class="col-md-6">
	<ul class="list-group"/><h4></h4>
		<?php
				$imag_query = mysqli_query($conn, "SELECT * FROM `imag` ORDER BY `imag_id` ASC");
				while($imag_fetch = mysqli_fetch_array($imag_query)){
		?>
			<?php
				}
		?>
		
	</ul>
</div>
	<?php
			}
	?>


</body>

</section>


















	
	 <section id="intro">







  <!-- JavaScript Libraries -->
  




    </section><!-- #about -->






    <!--==========================
    Call To Action Section
    ============================-->
    <section id="call-to-action">
      <div class="container wow fadeIn">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title"></h3>
            <p class="cta-text">















<section>

	<head>




		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" type="text/css" href="i2/css/bootstrap.css"/>
	</head>


	
		



</section>



<section>







	<head>	
		</head>
<body>















<section>

	

 Duis auteqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqq
qqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq







<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-down" data-aos-duration="2000">












		<div class="content_bottom">
    		<div class="heading">
    		<h3>kitchen accessories</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">
				<?php 




                $getBrandProSam = $pd->getBrandProductSamsung();
                if ($getBrandProSam) {
                    while ($result = $getBrandProSam->fetch_assoc()) {
                        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?php echo $result['productId'] ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['productName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'], 40); ?></p>
					 <p><span class="price"><?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                    }
                } ?>
			</div>




</section>



<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-up" data-aos-duration="2000">






		<div class="content_bottom">
    		<div class="heading">
    		<h3>Electronics</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">
			


	<?php 




                $getBrandProAcer = $pd->getBrandProductAcer();
                if ($getBrandProAcer) {
                    while ($result = $getBrandProAcer->fetch_assoc()) {
                        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?php echo $result['productId'] ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['productName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'], 40); ?></p>
					 <p><span class="price"><?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                    }
                } ?>				
			</div>


















</section>














	<div class="col-md-42"></div>
	<div class="col-md-75 well">





<?php
			require 'coa.php';


			
			$query = mysqli_query($conn, "SELECT * FROM `vid` ORDER BY `vid_id` ASC") or die(mysqli_error());
			while($fetch = mysqli_fetch_array($query)){
		?>
						<br />
				
				<h5 class="text-primary"><?php echo $fetch['vid_name']?></h5>
			</div>

				









                           <div class="col-md-22">
				<video width="288" height="240" controls>




	<source src="<?php echo $fetch['locatio']?>">
				</video>
			</div>







				</div>
		<?php
			}
		?>
	</div>
			</form>
		</div>
	</div>











<script src="aos/dist/aos.js"></script>
<script type="text/javascript">
     AOS.init({
           easing: 'ease-in-out-sine'
     });
</script>


</div>

	







					</section>

















<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-down" data-aos-duration="2000">



































<script src="aos/dist/aos.js"></script>
<script type="text/javascript">
     AOS.init({
           easing: 'ease-in-out-sine'
     });
</script>


</div>






</section>

































<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-down" data-aos-duration="2000">






<link href="style.css" rel="stylesheet" type="text/css" media="all"/>








 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Acer</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
				<?php 




                $getBrandProAcer = $pd->getBrandProductAcer();
                if ($getBrandProAcer) {
                    while ($result = $getBrandProAcer->fetch_assoc()) {
                        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?php echo $result['productId'] ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['productName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'], 40); ?></p>
					 <p><span class="price"><?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                    }
                } ?>				
			</div>

















<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-up" data-aos-duration="2000">







		<div class="content_bottom">
    		<div class="heading">
    		<h3>Samsung</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">
				<?php 




                $getBrandProSam = $pd->getBrandProductSamsung();
                if ($getBrandProSam) {
                    while ($result = $getBrandProSam->fetch_assoc()) {
                        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?php echo $result['productId'] ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['productName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'], 40); ?></p>
					 <p><span class="price"><?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                    }
                } ?>
			</div>
	<div class="content_bottom">
    		<div class="heading">
    		<h3>Canon</h3>
    		</div>







qqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqq
qqqqqqqqq





























<script src="aos/dist/aos.js"></script>
<script type="text/javascript">
     AOS.init({
           easing: 'ease-in-out-sine'
     });
</script>


</div>







</section>
































<script src="aos/dist/aos.js"></script>
<script type="text/javascript">
     AOS.init({
           easing: 'ease-in-out-sine'
     });
</script>


</div>







</section>










































<section>


<link rel="stylesheet" type="text/css" href="aos/dist/aos.css">



<section class=" images">


  
<div class="col-md-18" data-aos="fade-down" data-aos-duration="2000">








    <!--==========================
      Services Section
    ============================-->
    <section id="services">
      <div class="container wow fadeIn">
        <div class="section-header">
          <h3 class="section-title">Services</h3>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
            <div class="box">
              <div class="icon"><a href=""><i class="fa fa-desktop"></i></a></div>
              <h4 class="title"><a href="">Lorem Ipsum</a></h4>
              <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
            <div class="box">
              <div class="icon"><a href=""><i class="fa fa-bar-chart"></i></a></div>
              <h4 class="title"><a href="">Dolor Sitema</a></h4>
              <p class="description">Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata</p>
            </div>
          </div>
          </div>
        </div>

      </div>
    </section><!-- #services -->



















  <!--==========================
    Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">








			

    </div>
























    <!--==========================
      Team Section
    ============================-->
    <section id="team">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h3 class="section-title">Team</h3>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>




























<head>
</head>
<body>

      
				<div id="page-wrapper">

		
        </div>
			
					<br />
					






    </section><!-- #team -->








































  <!--==========================
    Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">


			




   <div class="container wow fadeInUp">
        <div class="section-header">
          <h3 class="section-title">Team</h3>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>
       


<div class="row">
       


          <div class="col-lg-18 col-md-14">
            <div class="member">
              <div class="pic"><img src="img/team-4.jpg" alt=""></div>
              <h4>Amanda Jepson</h4>
              <span>Accountant</span>
              <div class="social">
                <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a>
              </div>
            </div>



              </div>
            </div>



         










    </section><!-- #call-to-action -->









    <!--==========================
      Contact Section
    ============================-->























































  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">

      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy;  <strong>M.I.T</strong> 
      </div>
      <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://blicense/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=M.I.T
        -->
        Designed by <a href="https://bootstrapmade.com/">bd.simfebrica.info</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>




















	
	 <section id="intro">



	
	
	








				</div>





				</div>
    </div>



























































<?php
include('db.php');
?>












<!-- visitors -->
<!-- contact -->
<section class="contact-w3ls" id="contact">
	<div class="container">
		<div class="col-lg-6 col-md-6 col-sm-6 contact-w3-agile2" data-aos="flip-left">
			<div class="contact-agileits">
			
				
				<form  method="post" name="sentMessage" id="contactForm" >
					<div class="control-group form-group">
                        
                            <label class="contact-p1">message:</label>
                            <input type="text" class="form-control" name="name" id="name" required >
                            <p class="help-block"></p>
                       
                    </div>	
                    <div class="control-group form-group">
                        
                            <label class="contact-p1">Your Ph :</label>
                            <input type="tel" class="form-control" name="phone" id="phone" required >
							<p class="help-block"></p>
						
                    </div>
                    <div class="control-group form-group">
                        
                            <label class="contact-p1">Yourmail:</label>
                            <input type="email" class="form-control" name="email" id="email" required >
							<p class="help-block"></p>
						
                    </div>
                    
                    
                    <input type="submit" name="sub" value="Send Message Now" class="btn btn-success">	
				</form>
				<?php
				if(isset($_POST['sub']))
				{
					$name =$_POST['name'];
					$phone = $_POST['phone'];
					$email = $_POST['email'];
					$approval = "Not Allowed";
					$sql = "INSERT INTO `contact`(`fullname`, `phoneno`, `email`,`cdate`,`approval`) VALUES ('$name','$phone','$email',now(),'$approval')" ;
					
					
					if(mysqli_query($con,$sql))
					echo"OK";
					
				}
				?>
			</div>
		</div>





	    </div>









<!--/footer -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- contact form -->
<script src="js/jqBootstrapValidation.js"></script>







<!-- /contact form -->	
<!-- Calendar -->
		<script src="js/jquery-ui.js"></script>
		<script>
				$(function() {
				$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
				});
		</script>
<!-- //Calendar -->
<!-- gallery popup -->
<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script> 
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>
<!-- //gallery popup -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
<!--tabs-->
<script src="js/easy-responsive-tabs.js"></script>
<script>
$(document).ready(function () {
$('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
$('#verticalTab').easyResponsiveTabs({
type: 'vertical',
width: 'auto',
fit: true
});
});
</script>
<!--//tabs-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	
	<div class="arr-w3ls">
	<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>















  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>




</html>











